/* Copyright 2005 Renzo Davoli - VDE-2
 * Mattia Belletti (C) 2004.
 * Licensed under the GPLv2
 */ 

#ifndef _SOCKUTILS_H
#define _SOCKUTILS_H

int still_used(struct sockaddr_un *sun);

#endif
