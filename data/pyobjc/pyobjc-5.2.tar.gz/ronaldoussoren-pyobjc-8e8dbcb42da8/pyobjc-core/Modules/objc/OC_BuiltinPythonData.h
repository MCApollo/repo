#import "pyobjc.h"

@interface OC_BuiltinPythonData : OC_PythonData
{
}
@end
