#ifndef PyObjC_WEAKREF_H
#define PyObjC_WEAKREF_H

#if PyObjC_BUILD_RELEASE >= 1007
extern PyTypeObject PyObjCWeakRef_Type;
#endif /* PyObjC_BUILD_RELEASE >= 1007 */

#endif /* PyObjC_WEAKREF_H */

