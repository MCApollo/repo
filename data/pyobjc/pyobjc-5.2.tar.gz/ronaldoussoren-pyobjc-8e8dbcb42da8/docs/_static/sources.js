var tabberOptions = {
  titleElementsStripHTML: false
}
