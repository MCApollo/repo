This tree contains the document root for
all pyobjc subproject documentation sites
on packages.python.org, the HTML redirects
to the main documentation site.
