API Notes: InputMethodKit framework
===================================

The full API is described in `Apple's documentation`__, both
the C and Objective-C APIs are available (but see the `API Notes`_ below).

.. __: https://developer.apple.com/documentation/inputmethodkit/?preferredLanguage=occ

These bindings are accessed through the ``InputMethodKit`` package (that is, ``import InputMethodKit``).


API Notes
---------

All API's in the InputMethodKit are wrapped by PyObjC.
