API Notes: AppleScriptKit framework
===================================

API Notes
---------

The AppleScriptKit framework is wrapped completely by PyObjC.

These bindings are accessed through the ``AppleScriptKit`` package (that is, ``import AppleScriptKit``).
