API Notes: SyncServices framework
=================================

These bindings are accessed through the ``SyncServices`` package (that is, ``import SyncServices``).

API Notes
---------

PyObjC's bindings for the SyncServices framework are complete.

.. note::

   The entire framework is deprecated starting macOS 10.7, and it no longer
   documented on Apple's developer website.
