API Notes: AppleScriptObjC framework
====================================

Apple documentation
-------------------

The full API is described in Apple's documentation, both the C and Objective-C APIs are available.

These bindings are accessed through the ``AppleScriptKit`` package (that is, ``import AppleScriptKit``).



API Notes
---------

This framework is fully wrapped.
