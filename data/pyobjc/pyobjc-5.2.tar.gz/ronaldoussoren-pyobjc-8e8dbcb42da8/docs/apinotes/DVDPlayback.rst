API Notes: AE framework
=================================

Apple documentation
-------------------

The full API is described in `Apple's documentation`__, both
the C and Objective-C APIs are available (but see the `API Notes`_ below).

.. __: https://developer.apple.com/dvdplayback/?language=objc

These bindings are accessed through the ``DVDPlayback`` package (that is, ``import DVDPlayback``).


API Notes
---------

(none yet)
