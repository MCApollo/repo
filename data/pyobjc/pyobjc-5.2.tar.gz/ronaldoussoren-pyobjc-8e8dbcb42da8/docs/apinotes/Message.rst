API Notes: Message framework
============================

API Notes
---------

The PyObjC bindings for the Message framework are complete.

.. note::

   This framework is only available for 32-bit code, and
   was removed in macOS 10.9.
