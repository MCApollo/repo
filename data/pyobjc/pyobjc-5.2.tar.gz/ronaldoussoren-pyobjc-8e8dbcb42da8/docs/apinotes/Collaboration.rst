API Notes: Collaboration framework
==================================

The full API is described in `Apple's documentation`__, both
the C and Objective-C APIs are available (but see the `API Notes`_ below).

.. __: https://developer.apple.com/documentation/collaboration/?preferredLanguage=occ

These bindings are accessed through the ``Collaboration`` package (that is, ``import Collaboration``).


API Notes
---------

The Collaboration framework wrappers for PyObjC are complete.
