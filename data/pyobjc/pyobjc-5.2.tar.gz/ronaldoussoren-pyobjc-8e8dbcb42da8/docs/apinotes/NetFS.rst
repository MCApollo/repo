API Notes: NetFS framework
==========================

These bindings are accessed through the ``NetFS`` package (that is, ``import NetFS``).

.. note::

   I cannot find the API reference for this framework on Apple's developer website.


API Notes
---------

The Plugin API is not support (types ``NetFSMountInterface_V1`` and ``NetFSInterface``
and functions ``NetFSInterface_AddRef``, ``NetFSInterface_Release``,
``NetFS_CreateInterface`` and ``NetFSQueryInterface``)
