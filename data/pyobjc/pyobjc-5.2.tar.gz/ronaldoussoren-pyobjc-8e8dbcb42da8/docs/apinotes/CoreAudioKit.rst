API Notes: CoreAudioKit framework
=================================

Apple documentation
-------------------

The full API is described in `Apple's documentation`__, both
the C and Objective-C APIs are available (but see the `API Notes`_ below).

.. __: https://developer.apple.com/coreaudiokit/?language=objc

These bindings are accessed through the ``CoreAudioKit`` package (that is, ``import CoreAudioKit``).


API Notes
---------

* The full API can be used from Python
