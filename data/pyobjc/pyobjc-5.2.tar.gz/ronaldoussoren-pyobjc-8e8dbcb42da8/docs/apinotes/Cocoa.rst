API Notes: Cocoa framework
===========================

This is an umbrella framework for the ``AppKit`` and ``Foundation`` frameworks,
see the documentation for those frameworks for more information.
