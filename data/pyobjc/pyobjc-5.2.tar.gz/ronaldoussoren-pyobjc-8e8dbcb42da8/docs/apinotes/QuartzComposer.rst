API Notes: QuartzComposer framework
====================================

Apple documentation
-------------------

The full API is described in `Apple's documentation`__.

.. __: https://developer.apple.com/library/content/documentation/GraphicsImaging/Conceptual/QuartzComposerUserGuide/qc_intro/qc_intro.html

These bindings are accessed through the ``Quartz`` package (that is, ``import Quartz``).
