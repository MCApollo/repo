API Notes: QuartzCore framework
===============================

Apple documentation
-------------------

The full API is described in `Apple's documentation`__.

.. __: https://developer.apple.com/documentation/quartzcore?language=objc

These bindings are accessed through the ``Quartz`` package (that is, ``import Quartz``).
