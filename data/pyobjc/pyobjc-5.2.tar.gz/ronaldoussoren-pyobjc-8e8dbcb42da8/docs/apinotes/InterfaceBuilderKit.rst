API Notes: InterfaceBuilderKit framework
========================================

API Notes
---------

All API's in this framework have been wrapped by PyObjC.

This framework is only available when you have Xcode 3.x
installed, and furthermore the framework can only be used for
writing plugins and not as part of standalone applications.

.. note::

   This package will not work with Xcode 4, which is why
   the package won't install automaticly on macOS 10.8 (or later)

