API Notes: PubSub framework
===========================

This framework was deprecated by Apple and is no longer documentated on
Apple's developer website.

These bindings are accessed through the ``PubSub`` package (that is, ``import PubSub``).

API Notes
---------

The PyObjC bindings for the PubSub framework are complete.

.. note::

   This framework is deprecated in OSX 10.9
