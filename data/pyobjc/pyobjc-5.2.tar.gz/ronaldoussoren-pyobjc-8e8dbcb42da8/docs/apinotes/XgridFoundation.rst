API Notes: XgridFoundation framework
====================================

.. note:: 

   The XgridFoundation framework is not present in OSX 10.8 or later,
   which means the XgridFoundation package will raise ImportError when
   you try to use it on this release of OSX.

API Notes
---------

PyObjC's bindings for the XgridFoundation framework are complete.

