API Notes: ServerNotification framework
=======================================

API Notes
---------

.. note::

   This framework is only available on OSX 10.6, 10.7 and 10.8, and is no
   longer documented on Apple's developer website.

The entire framework is available from Python.
