API Notes: IMServicePlugIn framework
====================================

This framework was deprecated in macOS 10.13, and there no longer is
documentation on Apple's developer websites.

These bindings are accessed through the ``IMServicePlugin`` package (that is, ``import IMServicePlugin``).


API Notes
---------

The entire framework is available.

