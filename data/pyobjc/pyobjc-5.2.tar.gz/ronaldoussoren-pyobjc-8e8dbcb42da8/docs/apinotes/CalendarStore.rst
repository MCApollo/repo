API Notes: CalendarStore framework
==================================

These bindings are accessed through the ``CalendarStore`` package (that is, ``import CalendarStore``).


API Notes
---------

The CalendarStore framework is completely wrapped by PyObjC.

.. note::

   This framework is deprecated, use the ``EventKit`` framework instead (avaiable on OSX 10.8 or later)
