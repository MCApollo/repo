API Notes: CoreServices/OSServices framework
============================================

Apple documentation
-------------------

The full API is described in `Apple's documentation`__, both
the C and Objective-C APIs are available (but see the `API Notes`_ below).

.. __: https://developer.apple.com/documentation/coreservices/?preferredLanguage=occ


API Notes
---------

The OSServices framework is a subframework of OSServices, use
``import OSServices`` to access the definitions in this framework.
