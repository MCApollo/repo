API Notes: InstallerPlugins framework
=====================================

These bindings are accessed through the ``InstallerPlugins`` package (that is, ``import InstallerPlugins``).


API Notes
---------

All API's in the InstallerPlugins framework are wrapped by PyObjC.

.. warning::

   I cannot find documentation for this framework on Apple's developer
   website anymore, this likely means that this framework is on the
   way out (even if it doesn't appear to be officially deprecated).

.. note::

   As of macOS 10.12 this framework is only available for 64-bit code.
