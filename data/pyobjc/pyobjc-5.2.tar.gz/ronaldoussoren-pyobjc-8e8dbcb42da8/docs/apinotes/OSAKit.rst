API Notes: OSAKit framework
===========================

Apple documentation
-------------------

The full API is described in `Apple's documentation`__, both
the C and Objective-C APIs are available (but see the `API Notes`_ below).

.. __: https://developer.apple.com/osakit/?language=objc

These bindings are accessed through the ``OSAKit`` package (that is, ``import OSAKit``).


API Notes
---------

All APIs in this framework are available from Python.
