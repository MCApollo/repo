The PyObjC core team
====================

Current
-------

The current maintainer, and primary author, for PyObjC is
`Ronald Oussoren <ronaldoussoren@mac.com>`_. Ronald picked up
the orginal version of PyObjC and rewrote it to be able to
subclass Cocoa classes instead of just being able to use existing
Cocoa classes and objects.

Past
----

`Lele Gaifax <lele@metapensiero.it>`_ wrote the original version of PyObjC
back in the NeXTStep days.

`Bill Bumgarner <bbum@friday.com>`_ contributed to the original version
as well as to the reboot started by Ronald.

`Steve Majewski <sdm7g@minsky.med.virginia.edu>`_ and Bill Bumgarner
maintained PyObjC when Lele Gaifax stopped working on it.

