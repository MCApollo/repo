## 0.1.1 (2019-02-09)

* Add \_branch() method

## 0.1.0 (2019-02-09)

Initial release
