README - CUPS on macOS/iOS - 2016-08-08
---------------------------------------

This directory contains an Xcode project for building CUPS for macOS and the
CUPS library for iOS.
