
struct ether_hdr_t {
    MAC sa, da;
    uint16_t type;
};
